const modal = document.getElementById("modal");
const modalTitle = document.getElementById("modal-title");
const modalContent = document.getElementById("modal-content");
const consent = document.getElementById("consent");

document.getElementById("year").textContent = new Date().getFullYear();

const modules = {
  password: {
    title: "PASSWORD ANALYZER",
    html: `<p>Analyse effectuée directement dans ton navigateur. N'entre jamais un mot de passe que tu utilises réellement sur un compte important.</p>
      <label for="pw">Mot de passe de test</label><input id="pw" type="password" autocomplete="off" placeholder="Exemple fictif">
      <button class="action" id="analyze">ANALYZE</button><div class="result" id="pw-result">En attente d'une valeur de test.</div>`,
    init() {
      document.getElementById("analyze").onclick = () => {
        const value = document.getElementById("pw").value;
        let score = 0;
        if (value.length >= 12) score++;
        if (/[a-z]/.test(value) && /[A-Z]/.test(value)) score++;
        if (/\d/.test(value)) score++;
        if (/[^A-Za-z0-9]/.test(value)) score++;
        const labels = ["Très faible", "Faible", "Moyenne", "Bonne", "Meilleure"];
        document.getElementById("pw-result").textContent =
          `Évaluation indicative : ${labels[score]}. Longueur : ${value.length} caractères.`;
      };
    }
  },
  ip: {
    title: "IP INFORMATION",
    html: `<p>Une adresse IP peut révéler des informations approximatives sur une connexion. Elle ne permet pas, à elle seule, d'identifier précisément une personne ou son domicile.</p><div class="result">Conseil : évite de publier ton adresse IP ou celle d'une autre personne.</div>`
  },
  checklist: {
    title: "SECURITY CHECKLIST",
    html: `<p><label><input type="checkbox"> Activer l'authentification à deux facteurs</label></p><p><label><input type="checkbox"> Utiliser un mot de passe unique</label></p><p><label><input type="checkbox"> Installer les mises à jour</label></p><p><label><input type="checkbox"> Vérifier les sessions connectées</label></p>`
  },
  domain: {
    title: "DOMAIN LOOKUP",
    html: `<p>Entre un nom de domaine pour préparer une recherche publique. N'effectue des vérifications que sur des domaines que tu possèdes ou que tu es autorisé à examiner.</p><input id="domain-name" placeholder="example.com"><button class="action" id="domain-search">PREPARE SEARCH</button><div id="domain-result" class="result">Aucune recherche lancée.</div>`,
    init() {
      document.getElementById("domain-search").onclick = () => {
        const raw = document.getElementById("domain-name").value.trim();
        const valid = /^[a-z0-9.-]+\.[a-z]{2,}$/i.test(raw) && !raw.includes("..");
        document.getElementById("domain-result").textContent = valid
          ? `Domaine saisi : ${raw}. Vérifie-le avec un service WHOIS/RDAP public et fiable.`
          : "Entre un nom de domaine valide, par exemple example.com.";
      };
    }
  },
  generator: {
    title: "PASSWORD GENERATOR",
    html: `<p>Génère un mot de passe aléatoire localement. Copie-le dans un gestionnaire de mots de passe.</p><label for="length">Longueur (12 à 40)</label><input id="length" type="number" min="12" max="40" value="20"><button class="action" id="generate">GENERATE</button><div class="result" id="generated">En attente.</div>`,
    init() {
      document.getElementById("generate").onclick = () => {
        const length = Math.min(40, Math.max(12, Number(document.getElementById("length").value) || 20));
        const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%*-_";
        const bytes = new Uint32Array(length);
        crypto.getRandomValues(bytes);
        const result = Array.from(bytes, n => chars[n % chars.length]).join("");
        document.getElementById("generated").textContent = result;
      };
    }
  },
  network: {
    title: "NETWORK MONITOR",
    html: `<p>Le navigateur peut exposer quelques informations limitées sur la connexion. Il ne s'agit pas d'un scanner réseau.</p><div class="result" id="network-info"></div>`,
    init() {
      const c = navigator.connection;
      document.getElementById("network-info").textContent =
        `En ligne : ${navigator.onLine ? "Oui" : "Non"} · Type : ${c?.effectiveType || "Non disponible"} · Langue : ${navigator.language}`;
    }
  }
};

document.querySelectorAll("[data-tool]").forEach(button => {
  button.addEventListener("click", () => {
    const module = modules[button.dataset.tool];
    if (!module) return;
    modalTitle.textContent = module.title;
    modalContent.innerHTML = module.html;
    modal.hidden = false;
    module.init?.();
  });
});

function closeModal() { modal.hidden = true; }
document.getElementById("modal-close").addEventListener("click", closeModal);
modal.addEventListener("click", event => { if (event.target === modal) closeModal(); });
document.addEventListener("keydown", event => { if (event.key === "Escape") closeModal(); });

// Optional visit notification: only after a visitor actively accepts.
// Raw IP addresses are deliberately not collected or emailed.
const consentChoice = localStorage.getItem("darkcsint-visit-consent");
if (!consentChoice) consent.hidden = false;

function deviceCategory() {
  const ua = navigator.userAgent;
  if (/iPad|Tablet/i.test(ua)) return "Tablet";
  if (/Mobi|Android|iPhone/i.test(ua)) return "Mobile";
  return "Desktop";
}

async function sendVisitNotification() {
  try {
    await fetch("/api/visit-notification", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        page: location.pathname,
        userAgent: navigator.userAgent,
        device: deviceCategory()
      })
    });
  } catch {
    // Notification failure does not affect the website.
  }
}

document.getElementById("accept").addEventListener("click", () => {
  localStorage.setItem("darkcsint-visit-consent", "accepted");
  consent.hidden = true;
  sendVisitNotification();
});

document.getElementById("decline").addEventListener("click", () => {
  localStorage.setItem("darkcsint-visit-consent", "declined");
  consent.hidden = true;
});
