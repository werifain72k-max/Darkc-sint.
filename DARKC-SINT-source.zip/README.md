# DARKC-SINT

## Requirements
- Node.js 18 or newer
- SMTP account/provider for email notifications

## Run locally
1. Extract the ZIP.
2. Open a terminal in the project folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Fill in your SMTP provider settings. Keep `.env` private.
6. Run `npm start`.
7. Open `http://localhost:3000`.

## Email notifications
The notification is sent only after a visitor clicks ACCEPT on the privacy banner.
It includes timestamp, page path, device category, and browser user-agent.
This sample deliberately does not collect, store, or email raw IP addresses.
The notification endpoint is rate-limited.

## Important before publishing
- Replace the example SMTP settings with credentials from a trusted mail provider.
- Never upload `.env` to GitHub or expose SMTP credentials in frontend code.
- Publish a privacy notice explaining the data, purpose, retention period, and contact details.
- Check the privacy and cookie rules that apply where you operate.
- Use HTTPS when hosting publicly.
